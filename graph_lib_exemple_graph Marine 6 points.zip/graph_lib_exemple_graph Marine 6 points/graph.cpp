#include "graph.h"
#include <fstream>
using namespace std;
/***************************************************
                    VERTEX
****************************************************/

/// Le constructeur met en place les �l�ments de l'interface
VertexInterface::VertexInterface(int idx, int x, int y, std::string pic_name, int pic_idx)
{
    // La boite englobante
    m_top_box.set_pos(x, y);
    m_top_box.set_dim(130, 100);
    m_top_box.set_moveable();

    // Le slider de r�glage de valeur
    m_top_box.add_child( m_slider_value );
    m_slider_value.set_range(0.0, 100.0);  // Valeurs arbitraires, � adapter...
    m_slider_value.set_dim(20,80);
    m_slider_value.set_gravity_xy(grman::GravityX::Left, grman::GravityY::Up);

    // Label de visualisation de valeur
    m_top_box.add_child( m_label_value );
    m_label_value.set_gravity_xy(grman::GravityX::Left, grman::GravityY::Down);

    // Une illustration...
    if (pic_name!="")
    {
        m_top_box.add_child( m_img );
        m_img.set_pic_name(pic_name);
        m_img.set_pic_idx(pic_idx);
        m_img.set_gravity_x(grman::GravityX::Right);
    }

    // Label de visualisation d'index du sommet dans une boite
    m_top_box.add_child( m_box_label_idx );
    m_box_label_idx.set_gravity_xy(grman::GravityX::Right, grman::GravityY::Down);
    m_box_label_idx.set_dim(20,12);
    m_box_label_idx.set_bg_color(BLANC);

    m_box_label_idx.add_child( m_label_idx );
    m_label_idx.set_message( std::to_string(idx) );
}


/// Gestion du Vertex avant l'appel � l'interface
void Vertex::pre_update()
{
    if (!m_interface)
        return;

    /// Copier la valeur locale de la donn�e m_value vers le slider associ�
    m_interface->m_slider_value.set_value(m_value);

    /// Copier la valeur locale de la donn�e m_value vers le label sous le slider
    m_interface->m_label_value.set_message( std::to_string( (int)m_value) );
}


/// Gestion du Vertex apr�s l'appel � l'interface
void Vertex::post_update()
{
    if (!m_interface)
        return;

    /// Reprendre la valeur du slider dans la donn�e m_value locale
    m_value = m_interface->m_slider_value.get_value();
}



/***************************************************
                    EDGE
****************************************************/

/// Le constructeur met en place les �l�ments de l'interface
EdgeInterface::EdgeInterface(Vertex& from, Vertex& to)
{
    // Le WidgetEdge de l'interface de l'arc
    if ( !(from.m_interface && to.m_interface) )
    {
        std::cerr << "Error creating EdgeInterface between vertices having no interface" << std::endl;
        throw "Bad EdgeInterface instanciation";
    }
    m_top_edge.attach_from(from.m_interface->m_top_box);
    m_top_edge.attach_to(to.m_interface->m_top_box);
    m_top_edge.reset_arrow_with_bullet();

    // Une boite pour englober les widgets de r�glage associ�s
    m_top_edge.add_child(m_box_edge);
    m_box_edge.set_dim(24,60);
    m_box_edge.set_bg_color(BLANCBLEU);

    // Le slider de r�glage de valeur
    m_box_edge.add_child( m_slider_weight );
    m_slider_weight.set_range(0.0, 100.0);  // Valeurs arbitraires, � adapter...
    m_slider_weight.set_dim(16,40);
    m_slider_weight.set_gravity_y(grman::GravityY::Up);

    // Label de visualisation de valeur
    m_box_edge.add_child( m_label_weight );
    m_label_weight.set_gravity_y(grman::GravityY::Down);

}


/// Gestion du Edge avant l'appel � l'interface
void Edge::pre_update()
{
    if (!m_interface)
        return;

    /// Copier la valeur locale de la donn�e m_weight vers le slider associ�
    m_interface->m_slider_weight.set_value(m_weight);

    /// Copier la valeur locale de la donn�e m_weight vers le label sous le slider
    m_interface->m_label_weight.set_message( std::to_string( (int)m_weight ) );
}

/// Gestion du Edge apr�s l'appel � l'interface
void Edge::post_update()
{
    if (!m_interface)
        return;

    /// Reprendre la valeur du slider dans la donn�e m_weight locale
    m_weight = m_interface->m_slider_weight.get_value();
}



/***************************************************
                    GRAPH
****************************************************/

/// Ici le constructeur se contente de pr�parer un cadre d'accueil des
/// �l�ments qui seront ensuite ajout�s lors de la mise ne place du Graphe
GraphInterface::GraphInterface(int x, int y, int w, int h)
{
    m_top_box.set_dim(1000,740);
    m_top_box.set_gravity_xy(grman::GravityX::Right, grman::GravityY::Up);

    m_top_box.add_child(m_tool_box);
    m_tool_box.set_dim(80,720);
    m_tool_box.set_gravity_xy(grman::GravityX::Left, grman::GravityY::Up);
    m_tool_box.set_bg_color(BLANCBLEU);

    m_top_box.add_child(m_main_box);
    m_main_box.set_dim(908,720);
    m_main_box.set_gravity_xy(grman::GravityX::Right, grman::GravityY::Up);
    m_main_box.set_bg_color(BLANCJAUNE);

    /// ccreation de la toolbox
    m_top_box.add_child(m_deleteS);
    m_deleteS.add_child(m_text_deleteS);
    m_deleteS.set_dim(120,40);
    m_deleteS.set_posx(0);
    m_deleteS.set_posy(0);
    m_deleteS.set_bg_color(ROUGE);
    m_text_deleteS.set_message("  SUPPRIMER S ");

    /*     m_top_box.add_child(m_delete);
        m_delete.add_child(m_text_delete);
        m_delete.set_dim(120,40);
        m_delete.set_posx(0);
        m_delete.set_posy(40);
        m_delete.set_bg_color(ROUGE);
        m_text_delete.set_message("  SUPPRIMER A ");*/

    m_top_box.add_child(m_add);
    m_add.add_child(m_text_add);
    m_add.set_dim(120,40);
    m_add.set_posx(0);
    m_add.set_posy(80);
    m_add.set_bg_color(BLEU);
    m_text_add.set_message("  AJOUTER  ");


    m_top_box.add_child(m_save);
    m_save.add_child(m_text_save);
    m_save.set_dim(120,40);
    m_save.set_posx(0);
    m_save.set_posy(120);
    m_save.set_bg_color(KAKICLAIR);
    m_text_save.set_message("  SAUVEGARDER  ");

    m_top_box.add_child(m_return);
    m_return.add_child(m_text_return);
    m_return.set_dim(120,40);
    m_return.set_posx(0);
    m_return.set_posy(160);
    m_return.set_bg_color(VERT);
    m_text_return.set_message("  RETOUR  ");

    m_top_box.add_child(m_evolution);
    m_evolution.add_child(m_text_evolution);
    m_evolution.set_dim(120,40);
    m_evolution.set_posx(0);
    m_evolution.set_posy(200);
    m_evolution.set_bg_color(VERT);
    m_text_evolution.set_message("  EVOLUTION ");


    m_top_box.add_child(m_exit);
    m_exit.add_child(m_text_exit);
    m_exit.set_dim(120,40);
    m_exit.set_posx(0);
    m_exit.set_posy(240);
    m_exit.set_bg_color(BLANC);
    m_text_exit.set_message("QUITTER");

}


int ** Graph::allouer(int ordre)
{
    m_mat=new int*[ordre];                      ///Cr�ation de la matrice d'ordre donn� dans le fichier.

    for(int i=0; i<ordre; i++)
    {
        m_mat[i]=new int[ordre];
    }
    for (int j=0; j<ordre; j++)                 ///on initialise la matrice � 0.
    {
        for (int k=0; k<ordre; k++)
        {
            m_mat[j][k]=0;
        }
    }

    return m_mat;
}

void Graph ::Lire_fichier(string filename )
{
    /// ouverture du fichier en lecture
    ifstream fichier(filename.c_str(), ios::in);
    //int* temp=nullptr;
    string image;
    int indice_som =0;
    int x,y;
    int indice_edge;
    int som_in=0,som_out=0;
    int poids;
    double quantite;
    /// test d'ouverture de fichier
    if(fichier)
    {
        //temp=new int[m_ordre];
        m_interface = std::make_shared<GraphInterface>(50, 0, 750, 600);
        fichier>>m_ordre;  /// on lit la premi�re valeur du fichier qui est l'ordre.
        fichier>>m_aretes;
        for(int i=0; i<m_ordre; i++)
        {
            fichier>> indice_som>>quantite>> x >> y >>image;
            add_interfaced_vertex(indice_som, quantite, x, y,image);
        }
        int k=0;

        for(int j=0; j< m_aretes; j++)
        {
            fichier>>indice_edge>>som_in>>som_out>>poids;
            add_interfaced_edge(indice_edge, som_in, som_out, poids);
        }

        fichier.close();
    }
    else
    {
        cerr<<"Erreur. Ouverture de fichier impossible"<<endl;
    }
}

void Graph::Allouer_vect()
{
    m_vect.resize(m_ordre);
    for(int i=0; i<m_ordre; i++)
    {
        m_vect[i].resize(m_ordre);
    }

    for(int i=0; i<m_ordre; i++)
    {
        for(int j=0; j<m_ordre; j++)

        {
            m_vect[j].push_back(0);
        }

    }




}
BITMAP * load_bitmap_check(char *nomImage)
{
    BITMAP *bmp;
    bmp=load_bitmap(nomImage,NULL);
    if (!bmp)
    {
        allegro_message("pas pu trouver %s",nomImage);
        exit(EXIT_FAILURE);
    }
    return bmp;
}

void Graph :: menu()
{
    BITMAP  *page=NULL,*choix0=NULL,*choix1=NULL,*choix2=NULL,*choix3=NULL,*choix4=NULL;


    page=create_bitmap(SCREEN_W,SCREEN_H);
    choix0=load_bitmap("pics/darwin.bmp",NULL);


    blit( page,screen,0,0,0,0,SCREEN_W,SCREEN_H);



    choix1=load_bitmap("pics/darwin_t1.bmp",NULL);
    choix2=load_bitmap("pics/darwin_t2.bmp",NULL);
    choix3=load_bitmap("pics/darwin_t3.bmp",NULL);
    choix4=load_bitmap("pics/darwin_q.bmp",NULL);

    int choix=0;

    while(choix != 4 || !mouse_b&1 )
    {
        if( 403<=mouse_x && mouse_x<=858 && 51<=mouse_y && mouse_y<=163 )
        {
            choix=1;
            draw_sprite(page,choix1,0,0);
        }
        else if (465<=mouse_x && mouse_x<=922 && 207<= mouse_y && mouse_y<=324)
        {
            choix=2;
            draw_sprite(page,choix2,0,0);
        }
        else if ( 517<= mouse_x && mouse_x<= 965 && 381 <= mouse_y && mouse_y <=495)
        {
            choix=3;
            draw_sprite(page,choix3,0,0);
        }
        else if ( 618 <= mouse_x && mouse_x <= 951 && 628<= mouse_y && mouse_y<= 747)
        {
            choix=4;
            draw_sprite(page,choix4,0,0);
        }


        else
        {
            choix=0;
            draw_sprite(page,choix0,0,0);
        }



        draw_sprite(screen,page,0,0);
        rest(20);
        clear_bitmap(page);


        if(mouse_b&1 && choix<=4 && choix>=1)
        {
            switch(choix)
            {
            case 1:
            {
                choix=4;
                fichier="trophique1.txt";
                Lire_fichier(fichier);
                break;
            }
            case 2:
            {
                choix=4;
                fichier="trophique2.txt";
                Lire_fichier(fichier);
                break;
            }
            case 3:
            {
                choix=4;
                fichier="trophique3.txt";
                Lire_fichier(fichier);
                break;
            }
            case 4:
            {
                exit(1);
            }

            }

        }

    }
}

void Graph:: ajouterS()
{
    string image;
    int lien1,poids;
    cout<<"le nom de l'image a ajouter"<<endl;
    cin>>image;
    int successeur;
    cout<<" Veuillez saisir ses liens: "<<endl;
    cout<<"lien 1 :"<<endl;
    cin>>lien1;
    cout<<"poids :"<<endl;
    cin>> poids;

    int  a=m_vertices.size()+1;

    add_interfaced_vertex(0,0,0,0,image);
    for(map<int, Vertex>::iterator it=m_vertices.begin(); it!=m_vertices.end(); it++)
    {
        if(it->second.m_interface->m_img.get_pic_name()==image)
        {
            add_interfaced_edge(0,it->first,lien1,poids);
        }
    }
}

void Graph::supprimerS(int eidx)
{
    int num ;
    vector <int> vect_ind;

    for(map<int, Edge>::iterator et=m_edges.begin(); et!=m_edges.end(); et++)
    {
        if(et->second.get_from()==eidx || et->second.get_to()==eidx)
        {
            vect_ind.push_back(et->first);
        }
    }
    for(auto elem: vect_ind)
    {
        test_remove_edge(elem);
    }

    for(map<int, Vertex>::iterator it=m_vertices.begin(); it!=m_vertices.end(); it++)
    {
        it->first;
        it->second;
        if(it->first==eidx)
        {
            Vertex &remed=m_vertices.at(eidx);
            if(m_interface && remed.m_interface)
            {
                m_interface->m_main_box.remove_child(remed.m_interface->m_top_box);
            }
            m_vertices.erase( eidx );
            break;

        }
    }



}


void Graph::test_remove_edge(int eidx)
{
    Edge &remed=m_edges.at(eidx);

    std::cout << "Removing edge " << eidx << " " << remed.m_from << "->" << remed.m_to << " " << remed.m_weight << std::endl;

    /// test : on a bien des �l�ments interfac�s
    if (m_interface && remed.m_interface)
    {
        /// Ne pas oublier qu'on a fait �a � l'ajout de l'arc :
//         EdgeInterface *ei = new EdgeInterface(m_vertices[id_vert1], m_vertices[id_vert2]);
//         m_interface->m_main_box.add_child(ei->m_top_edge);
//         m_edges[idx] = Edge(weight, ei);
        /// Le new EdgeInterface ne n�cessite pas de delete car on a un shared_ptr
        /// Le Edge ne n�cessite pas non plus de delete car on n'a pas fait de new (s�mantique par valeur)
        /// mais il faut bien enlever le conteneur d'interface m_top_edge de l'arc de la main_box du graphe
        m_interface->m_main_box.remove_child( remed.m_interface->m_top_edge );
    }

    /// Il reste encore � virer l'arc supprim� de la liste des entrants et sortants des 2 sommets to et from !
    /// References sur les listes de edges des sommets from et to
    std::vector<int> &vefrom = m_vertices[remed.m_from].m_out;
    std::vector<int> &veto = m_vertices[remed.m_to].m_in;
    vefrom.erase( std::remove( vefrom.begin(), vefrom.end(), eidx ), vefrom.end() );
    veto.erase( std::remove( veto.begin(), veto.end(), eidx ), veto.end() );

    /// Le Edge ne n�cessite pas non plus de delete car on n'a pas fait de new (s�mantique par valeur)
    /// Il suffit donc de supprimer l'entr�e de la map pour supprimer � la fois l'Edge et le EdgeInterface
    /// mais malheureusement ceci n'enlevait pas automatiquement l'interface top_edge en tant que child de main_box !
    m_edges.erase( eidx );
    m_nb_arcs--;
}

void Graph::retour()
{
    BITMAP  *page=NULL,*choix0=NULL;


    page=create_bitmap(SCREEN_W,SCREEN_H);
    choix0=load_bitmap("pics/darwin.bmp",NULL);


    blit( page,screen,0,0,0,0,SCREEN_W,SCREEN_H);

}

void Graph::Menu_afficher()
{
    BITMAP*page;
    BITMAP*decor;

    page=create_bitmap(SCREEN_W,SCREEN_H);
    clear_bitmap(page);

    decor=load_bitmap("darwin.bmp",NULL);
    if (!decor)
    {
        allegro_message("pas pu trouver darwin.bmp");
        exit(EXIT_FAILURE);
    }

    while (!key[KEY_ESC])
    {
        // effacer buffer en appliquant d�cor  (pas de clear_bitmap)
        blit(decor,page,0,0,400,300,SCREEN_W,SCREEN_H);


        // affichage du buffer � l'�cran
        blit(page,screen,0,0,0,0,SCREEN_W,SCREEN_H);

        // la petite pause...
        rest(10);
    }

}

/// La m�thode update � appeler dans la boucle de jeu pour les graphes avec interface
void Graph::update()
{
    if (!m_interface)
        return;


    for (auto &elt : m_vertices)
        elt.second.pre_update();

    for (auto &elt : m_edges)
        elt.second.pre_update();

    m_interface->m_top_box.update();

    int a=m_interface->update();

    if(a==1)
    {
        int eidx;
        cout<<" Veuillez saisir l'indice du sommet a supprimer"<<endl;
        cin>> eidx;
        supprimerS(eidx);///suppression
    }
    if(a==2)
    {

        Sauvegarder_fichier(fichier);
    }
    if(a==3)
    {
        ajouterS(); ///ajouter
    }

    if(a==4)
    {
        retour();
    }
    if(a==5)
    {
        // evolution();
    }
    if(a==6)
    {
        exit(1);
    }

    m_interface->update();

    for (auto &elt : m_vertices)
        elt.second.post_update();

    for (auto &elt : m_edges)
        elt.second.post_update();


}

int GraphInterface::update()
{
    if(m_deleteS.clicked())
    {
        return 1;
    }
    if(m_save.clicked())
    {
        return 2;
    }
    if(m_add.clicked())
    {
        return 3;
    }
    if(m_return.clicked())
    {
        return 4;
    }
    if(m_evolution.clicked())
    {
        return 5;
    }
    if(m_exit.clicked())
    {
        return 6;
    }
}


void Graph::Sauvegarder_fichier(string filename )
{

    /// ouverture du fichier en �criture
    std::ofstream file(filename );

    /// test d'ouverture de fichier
    if(file)
    {
        file << m_vertices.size() << endl;
        file << m_edges.size()<< endl;

        for(map<int, Vertex>::iterator it=m_vertices.begin(); it!=m_vertices.end(); it++)
        {
            file<< it->first <<" "<<it->second.m_value << " "<<it->second.m_interface->m_top_box.get_posx() << " "<<it->second.m_interface->m_top_box.get_posy()<< " "<<it->second.m_interface->m_img.get_pic_name()<<endl;
        }
        for(map<int, Edge>::iterator et=m_edges.begin(); et!=m_edges.end(); et++)
        {
            file<<et->first<<" "<< et->second.get_from()<<" "<< et->second.get_to()<<" "<<et->second.get_weight()<<endl;
        }

        file.close();
    }
    else
    {
        cerr<<"Erreur. Ouverture de fichier impossible"<<endl;
    }
}

/*
void Graph::evolution()
{

    int k=0;


    std::map<int,Vertex>::iterator it3;

    int s=0;
    /// cherche de la proie (it3)
    for( std::map<int,Vertex>:: iterator it= m_vertices.begin(); it!=m_vertices.end(); it++) /// predateur
    {
        it->second.m_value; /// second -> vertex qui ont un attribut m_value

        for(std::map<int, Edge>:: iterator it2=m_edges.begin(); it2!=m_edges.end(); it2++) /// proie
        {

            if(it->first == it2->second.m_to)/// arete de la proie qui vient evrs le predateur
            {
                s=it2->second.m_from;

                it3=m_vertices.find(s);

            }

            for( std::map<int,Vertex>::iterator it4=m_vertices.begin(); it4!=m_vertices.end(); it4++)
            {
                if(it4->first==s)
                {
                    k+=it2->second.m_weight*it4->second.m_value;
                }


            }
            it->second.m_value+=0.4*it->second.m_value*(1-(it->second.m_value/k)) ;
            for( std::map<int,Vertex>::iterator it4 = m_edges.begin(); it4!=m_edges.end(); it4++) /// proie
            {
                if(it->first==it2->second.m_from)/// arete du predateur qui vient evrs le predateur
                {
                    it->second.m_value-=it2->second.m_weight*it4->second.m_value;

                }

            }

        }
    }

}
*/
int Edge::get_from()
{
    return m_from;
}

int Edge::get_to()
{
    return m_to;
}

int Edge::get_weight()
{
    return m_weight;
}

int Vertex::get_indice()
{
    return m_indice;
}
void Vertex::set_indice(int indice)
{
    m_indice=indice;
}
/// Aide � l'ajout de sommets interfac�s
void Graph::add_interfaced_vertex(int idx, double value, int x, int y, std::string pic_name, int pic_idx )
{

    while ( m_vertices.find(idx)!=m_vertices.end() )
    {
        idx++;
    }

    // Cr�ation d'une interface de sommet
    VertexInterface *vi = new VertexInterface(idx, x, y, pic_name, pic_idx);
    // Ajout de la top box de l'interface de sommet
    m_interface->m_main_box.add_child(vi->m_top_box);
    // On peut ajouter directement des vertices dans la map avec la notation crochet :
    m_vertices[idx] = Vertex(value, vi);
}

/// Aide � l'ajout d'arcs interfac�s
void Graph::add_interfaced_edge(int idx, int id_vert1, int id_vert2, double weight)
{
    while ( m_edges.find(idx)!=m_edges.end() )
    {
        idx++;
    }

    if ( m_vertices.find(id_vert1)==m_vertices.end() || m_vertices.find(id_vert2)==m_vertices.end() )
    {
        std::cerr << "Error adding edge idx=" << idx << " between vertices " << id_vert1 << " and " << id_vert2 << " not in m_vertices" << std::endl;
        throw "Error adding edge";
    }

    EdgeInterface *ei = new EdgeInterface(m_vertices[id_vert1], m_vertices[id_vert2]);
    m_interface->m_main_box.add_child(ei->m_top_edge);
    m_edges[idx] = Edge(weight, ei);

    m_edges[idx].m_from = id_vert1;
    m_edges[idx].m_to = id_vert2;

    m_vertices[id_vert1].m_out.push_back(idx);
    m_vertices[id_vert2].m_in.push_back(idx);
}

